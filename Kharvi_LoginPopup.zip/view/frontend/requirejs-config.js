var config = {
    map: {
        "*" : {
            loginpopup: "Kharvi_LoginPopup/js/loginpopup.js"
        }
    }
}